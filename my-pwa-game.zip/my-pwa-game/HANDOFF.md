# Handoff from the cloud session

Notes from the Claude Code cloud session that set this project up. Project conventions live in
`CLAUDE.md`; this file is only the starting state. Delete it once the first steps are done.

## The owner and the goal

- Building a mobile game as a PWA for iPhone, hosted on Cloudflare. Works on Linux, tests on an
  iPhone, and sometimes drives Claude from the Claude iPhone app.
- Wants the workspace saved on their own machine and the game hosted on Cloudflare.
- **Phaser 4 was my default; they never explicitly chose it.** Confirm it fits their game before
  building much on it. The "Tap Rush" demo is a placeholder that exists to prove the pipeline.
- The game has no name yet: "My PWA Game" / `my-pwa-game` are placeholders (README → Renaming).

## Current state

Stack: Phaser 4.2, TypeScript 7 (native `tsc`), Vite 8 (Rolldown), vite-plugin-pwa 2 with
generated icons, Vitest 5, Biome 2, Playwright 1.63, Wrangler 4 (Workers static assets).

Verified in the cloud session:

- `npm run check` (typecheck, lint, 8 unit tests) and `npm run build` pass.
- `npx playwright test --project=iphone-chromium`: 3/3 pass (boots, installable manifest, works offline).
- A full round played in an emulated iPhone 15 (Chromium): title → play → scoring → round end →
  best score saved and shown.
- `npm run cf:dev`: `/assets/*` gets immutable caching, `sw.js` gets `max-age=0, must-revalidate`,
  `_headers` isn't served, unknown paths fall back to `index.html`.

Never run yet:

- `npm run phone` / `phone:preview`: the cloud blocks public tunnels, so only the parts before the
  tunnel were checked (imports, dev server start, QR rendering).
- The `iphone-webkit` Playwright project (WebKit wasn't installed); CI runs only `iphone-chromium`
  for that reason.
- A real Cloudflare deploy, a real iPhone install, and the GitHub Actions workflow (no remote yet).

## First steps

1. `npm install` (Node 22+, see `.nvmrc`), then `npm run check`.
2. `npm run phone`; have the owner scan the QR code with their iPhone and confirm the game loads
   and hot reload works. Then `npm run phone:preview` and check Add to Home Screen and that it
   still opens in airplane mode.
3. `npx playwright install --with-deps chromium webkit` (system libraries need sudo), then
   `npm run e2e`. If `iphone-webkit` passes, add it to `.github/workflows/ci.yml`.
4. Help the owner create a GitHub repository and push `main`.
5. Cloudflare: `npx wrangler login` then `npm run deploy`, or connect the GitHub repository in the
   dashboard (Workers & Pages → Create → Import a repository; build `npm run build`, deploy
   `npx wrangler deploy`). Give the owner the workers.dev URL to install on their iPhone.
6. Ask what game they actually want to make, confirm the engine, pick a name, replace the demo.

## Gotchas

- `npm audit` reports 4 low-severity advisories (deepmerge via workbox-build, build-time only).
  Don't run `npm audit fix --force`: it "fixes" them by downgrading vite-plugin-pwa to 0.2.1.
- Vite 8 uses Rolldown: chunk splitting is `build.rolldownOptions.output.codeSplitting`, not
  `rollupOptions.manualChunks`.
- The quick-tunnel URL changes every run, so a Home Screen install from it won't last; install
  from the Cloudflare URL.
